/*
 * File:   main.c
 * Author: Sreeram
 *
 * Created on 10 September, 2026, 2:52 PM
 */
/*

 */


#include <xc.h>
#include<stdio.h>


// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define _XTAL_FREQ 20000000
#define SPI_SCK  RD0
#define SPI_SDO  RD1
#define SPI_CS   RD2

void UART_Init(long baud_rate) 
{
    TXSTA = 0x24;
    RCSTA = 0x90;
    SPBRG = (_XTAL_FREQ / (16UL * baud_rate)) - 1;
    TRISC6 = 1;
    TRISC7 = 1;
}

void UART_Write_Text(char *text) 
{
    int i;
    for (i = 0; text[i] != '\0'; i++) 
    {
        while (!TXIF);     
        TXREG = text[i];
    }
}

void I2C_Init() 
{
    TRISC3 = 1;
    TRISC4 = 1;
    SSPCON = 0x28;      
    SSPCON2 = 0x00;
    SSPADD = (_XTAL_FREQ / (4UL * 100000)) - 1; 
    SSPSTAT = 0x00;
}

void I2C_Start() 
{
    SEN = 1;
    while (SEN);
}

void I2C_Stop() 
{
    PEN = 1;
    while (PEN);
}

void I2C_Write(unsigned char data) 
{
    SSPBUF = data;
    while (BF);        
}

void SPI_Init() 
{
    TRISD0 = 0; 
    TRISD1 = 0; 
    TRISD2 = 0;
    SPI_CS = 1;
    SPI_SCK = 0;
}

void SPI_Write(unsigned char data) 
{
    unsigned char i;
    SPI_CS = 0;
    for (i = 0; i < 8; i++) {
        SPI_SDO = (data & 0x80) ? 1 : 0;
        data <<= 1;
        SPI_SCK = 1;
        __delay_us(2);
        SPI_SCK = 0;
        __delay_us(2);
    }
    SPI_CS = 1;
}

unsigned int ADC_Read(void) 
{
    ADCON0 = 0x81;        
    __delay_us(30);      
    GO_nDONE = 1;
    while (GO_nDONE);
    return ((ADRESH << 8) + ADRESL);
}

void main()
{
    unsigned int adc_value;
    unsigned int temperature;
    char buffer[30];
    TRISA0 = 1;
    ADCON1 = 0x80;        
    UART_Init(9600);
    I2C_Init();
    SPI_Init();

    while (1) 
    {
        adc_value = ADC_Read();
        temperature = (adc_value * 500UL) / 1023;   
        sprintf(buffer, "Temp: %u C\r\n", temperature);
        UART_Write_Text(buffer);
        SPI_Write((unsigned char) temperature);
        I2C_Start();
        I2C_Write(0x40);
        I2C_Write((unsigned char) temperature);
        I2C_Stop();
        __delay_ms(500);
    }
}
